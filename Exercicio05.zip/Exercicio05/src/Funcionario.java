public class Funcionario {

    //Criando Atributos
    public String nome;
    public String cargo;
    public double salario;


    //Criando o Construtor
    public Funcionario(String nome, String cargo, double salario) {
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;
    }
    //Implementando Método(s)
    //Primeiro: criando o método toString()
    @Override
    public String toString() {
        return "[Informações Funcionário]" + "\r\n" +
                "Nome: " + nome + "\r\n" +
                "Cargo: " + cargo + "\r\n" +
                "Salário: " + salario + "\r\n";
    }
}