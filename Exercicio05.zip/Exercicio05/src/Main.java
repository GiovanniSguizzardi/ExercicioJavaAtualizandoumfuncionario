public class Main {
    public static void main(String args[]) {
        //Instanciando as classes e dando as devidas informações
        Funcionario f = new Funcionario("Yan", "Estagiario", 1250);
        Gerente g = new Gerente("Ednaldo");
        System.out.println(f);

        //Chamando os métodos presentes na classe Gerente.java
        g.atualizar(f, f.cargo);
        g.atualizar(f, f.salario);
        System.out.println(f);
    }
}