public class Gerente {

    //Criando Atributos
    public String nome;

    //Criando o Construtor para ver o nome do Gerente impresso
    public Gerente(String nome){
        this.nome = nome;
    }

    //Implementando Método(s)
    //Primeiro: criando o método atualizar(cargo)
    public void atualizar(Funcionario f, String cargo) {
        f.cargo = "Desenvolvedor (NOVO CARGO!)";
    }

    //Segundo: criando o método atualizar(salario)
    public void atualizar(Funcionario f, double salario) {
        f.salario = 1580.50;
    }
}